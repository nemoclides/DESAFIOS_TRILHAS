/*Imagine que o seu irmão esteja aprendendo programação e o professor
lhe solicitou um algoritmo que imprima os números de 1 a 10. 
Como seria a implementação desse algoritmo para que ele possa apresentá-lo ao seu professor? */

for (let i=1; i <= 10; i ++ ) {

    alert (i)

}

