/*O Daniel está aprendendo a programar com seu pai, que é engenheiro de software. 
Um dia, seu pai pediu que ele criasse um programa simples: receber dois números do 
usuário e retornar o resultado da multiplicação deles. Para ajudar o Daniel, como seria a implementação desse algoritmo?
*/

let número1 = parseFloat (prompt ("Digite um número"));
let número2 = parseFloat (prompt ("Digite o outro"));
let resultado = número1*número2

alert (resultado)
