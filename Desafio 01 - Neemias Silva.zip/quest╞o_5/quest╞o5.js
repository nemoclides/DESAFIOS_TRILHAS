/*Suponha que o seu primo tenha interesse em produzir um algoritmo que 
imprima os números de 20 até 1 em ordem decrescente e pediu ajuda a você. 
Como você implementaria esse algoritmo?
*/

for (let i=20; i >= 1; i -- ) {

    alert (i)

}
